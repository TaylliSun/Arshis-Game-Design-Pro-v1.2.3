# Privacy Policy

## Network Activity
**This skill does not make outbound network requests.**
No HTTP calls, no API connections, no telemetry.

## Data Collection
**This skill does not collect or upload user data.**
No analytics, no tracking, no user profiling.

## Data Storage
**All generated outputs remain local to the OpenClaw environment.**
Files are written only within the skill's own `data/` directory.

## Child Process Usage
This skill uses Node.js `child_process.spawn()` to run local Python scripts:
- Only scripts bundled with this skill (`scripts/*.py`)
- Fixed script paths — never constructed from user input
- User input passed as arguments, never executed as commands

## How to Delete Data
Delete the `data/` folder inside the skill directory.

## Third-Party Dependencies
| Dependency | Purpose | Network? |
|-----------|---------|----------|
| `numpy` (Python) | Numeric calculations | No |
| `pandas` (Python) | Table generation | No |
| `requests` (Python) | Available but NOT used by this skill | No |

