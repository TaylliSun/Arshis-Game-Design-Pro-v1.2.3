# Arshis-Game-Design-Pro

> **Professional game design workflow assistant** for indie developers and small teams.

Generate structured game design documents, review designs for risks, plan Unity technical specifications, and explore innovative concepts — all through natural language.

## What It Does

This skill helps you go from a game idea to production-ready design:

1. **Generate GDDs** — Structured game design documents with clear sections, not walls of text
2. **Review Designs** — Check completeness, identify risks, get improvement suggestions
3. **Plan Technical Specs** — Unity scripts, variables, data structures, development phases
4. **Explore Innovations** — Differentiated concepts through a structured innovation pipeline
5. **Check Consistency** — Catch contradictions between story, mechanics, and worldbuilding
6. **Export Anywhere** — Markdown, Obsidian, GDD, technical plan, or publisher pitch

## What It Is NOT

- Not a memory plugin
- Not a replacement for professional game designers
- Not a game engine or code generator
- Does not make external network requests
- Does not require API keys

## Quick Examples

### 1. Generate an Innovative Game Concept
```
generate_innovative_design({
  genre: "roguelike",
  theme: "time manipulation",
  target_emotion: "melancholy",
  output_mode: "markdown"
})
```
**Output**: Full innovation design document with genre convention analysis, 5 unique concepts (Safe/Moderate/High/Experimental/Indie), each with novelty filter check, 6-metric scoring, Unity prototype plan, and MVP scope.

**When to use**: You have a genre + theme and want differentiated design ideas that are indie-feasible.

### 2. Review an Existing Design's Innovation Level
```
review_innovation_level({
  genre: "rpg",
  theme: "farming",
  design_content: "# My Game\n\nPlayers grow crops, sell them for gold..."
})
```
**Output**: Innovation score across 4 metrics, common vs different elements, reskin detection, improvement suggestions, indie feasibility tips.

**When to use**: You have a design document and want to know how innovative it is and how to improve it.

### 3. Convert GDD Idea into Unity Technical Planning
```
gdd_to_tech({
  gdd_text: "NPC relationship system where players build bonds through gifts and quests...",
  profile_file: "profile_my_game.json",
  output_mode: "technical_plan"
})
```
**Output**: Required Unity systems, C# script names (PascalCase), variable tables (with types), event systems, UI screens, art/audio asset lists, development phases with timeline.

**When to use**: You have a game design idea and need a technical specification to hand to developers.

## Full Tool Reference

### Core Design
- `generate_design({ doc_type, topic, details, word_count })`
- `review_design({ content, doc_type })`
- `check_consistency({ content_type, content_data })`
- `store_worldview({ category, content, importance })`
- `query_worldview({ query, limit })`

### Workflow
- `create_project_profile({ game_title, genre, platform, target_audience, core_loop, visual_style, engine, team_size, scope, reference_games })`
- `gdd_to_tech({ gdd_text, profile_file, obsidian })`
- `consistency_review({ design_json, profile_file, obsidian })`
- `review_score({ design_text, profile_file })`
- `obsidian_export({ profile_file })`

### Professional
- `professional_design({ topic, genre, details })`
- `production_spec({ topic, genre, details })`
- `combined_design({ topic, modes: "professional,innovation,production" })`
- `get_template_doc({ template_key })` — 10 templates available

### Innovation Engine
- `generate_innovative_design({ genre, theme, target_emotion, output_mode })`
- `review_innovation_level({ genre, theme, design_content })`

## Output Modes
- `json` — Raw structured data
- `markdown` / `gdd` — Professional GDD format
- `obsidian` — Obsidian with YAML frontmatter and internal links
- `technical_plan` — Unity implementation plan
- `publisher_pitch` — One-page pitch for publishers

## Privacy
- **No outbound network requests**
- **No data collection or upload**
- **No API keys required**
- **All outputs remain local**

## Supported Genres (25)
RPG, Roguelike, Platformer, Puzzle, Simulation, Action, Strategy, Survival, Horror, Farming, Tower Defense, Deckbuilding, Metroidvania, Monster Taming, Survival Crafting, Management Sim, Visual Novel, Puzzle Adventure, Tactical RPG, City Builder, Rhythm Game, Cozy Exploration, Idle Game, Party Game, Social Deduction.

## Requirements
- OpenClaw 2026.4.0+
- Python 3.9+

## License
MIT

---
*Arshis-Game-Design-Pro v2.4.3*
*A game design workflow assistant for indie developers and small teams.*
