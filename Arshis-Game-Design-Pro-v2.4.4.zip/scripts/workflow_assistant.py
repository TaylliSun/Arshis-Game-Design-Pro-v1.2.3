#!/usr/bin/env python3
"""
Indie Game Design Workflow Assistant v2.2.0

Helps indie developers progress from game idea to development-ready plan.
Generates: Project Profile, GDD, Technical Design, Art Requirements,
Development Priority, Consistency Review, and Obsidian Export.

Security: This script reads/writes only within the skill directory.
No network requests, no shell commands, no user file access.
"""

import os
import sys
import json
from datetime import datetime

# Data directory within the skill
DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'data')
PROFILES_DIR = os.path.join(DATA_DIR, 'profiles')
os.makedirs(PROFILES_DIR, exist_ok=True)


class ProjectProfile:
    """Game project profile - metadata and core design decisions."""

    REQUIRED_FIELDS = [
        'game_title', 'genre', 'platform', 'target_audience',
        'core_loop', 'visual_style', 'engine', 'team_size',
        'scope', 'reference_games'
    ]

    def __init__(self, data=None):
        self.data = data or {}
        self.data.setdefault('created_at', datetime.now().isoformat())
        self.data.setdefault('updated_at', datetime.now().isoformat())

    def save(self, filename=None):
        title = self.data.get('game_title', 'untitled').replace(' ', '_').lower()
        filename = filename or f"profile_{title}.json"
        filepath = os.path.join(PROFILES_DIR, filename)
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(self.data, f, indent=2, ensure_ascii=False)
        return filepath

    @classmethod
    def load(cls, filename):
        filepath = os.path.join(PROFILES_DIR, filename)
        with open(filepath, 'r', encoding='utf-8') as f:
            return cls(json.load(f))

    @classmethod
    def list_all(cls):
        if not os.path.exists(PROFILES_DIR):
            return []
        return [f for f in os.listdir(PROFILES_DIR) if f.endswith('.json')]

    def to_markdown(self, obsidian=False):
        lines = []
        if obsidian:
            lines.append('---')
            lines.append(f'title: "{self.data.get("game_title", "Untitled")}"')
            lines.append(f'genre: {self.data.get("genre", "")}')
            lines.append(f'engine: {self.data.get("engine", "")}')
            lines.append(f'platform: {self.data.get("platform", "")}')
            lines.append(f'team_size: {self.data.get("team_size", "")}')
            lines.append(f'created: {self.data.get("created_at", "")}')
            lines.append('tags: [game-design, project-profile]')
            lines.append('---')
            lines.append('')

        lines.append(f"# {self.data.get('game_title', 'Untitled')} - Project Profile")
        lines.append('')
        lines.append('## Overview')
        lines.append('')
        fields = {
            'Genre': self.data.get('genre', ''),
            'Platform': self.data.get('platform', ''),
            'Engine': self.data.get('engine', ''),
            'Visual Style': self.data.get('visual_style', ''),
            'Target Audience': self.data.get('target_audience', ''),
            'Team Size': self.data.get('team_size', ''),
            'Scope': self.data.get('scope', ''),
        }
        for k, v in fields.items():
            lines.append(f'- **{k}**: {v}')
        lines.append('')
        lines.append('## Core Gameplay Loop')
        lines.append('')
        loop = self.data.get('core_loop', 'Not specified')
        lines.append(loop)
        lines.append('')

        if obsidian:
            lines.append('```mermaid')
            lines.append('graph LR')
            parts = [p.strip() for p in loop.split('->') if p.strip()]
            if len(parts) >= 2:
                for i in range(len(parts)):
                    lines.append(f'    {parts[i]} --> {parts[(i+1)%len(parts)]}')
            else:
                lines.append(f'    Action --> Result --> Action')
            lines.append('```')
            lines.append('')

        lines.append('## Reference Games')
        lines.append('')
        refs = self.data.get('reference_games', [])
        if isinstance(refs, list):
            for r in refs:
                lines.append(f'- {r}')
        else:
            lines.append(f'- {refs}')
        lines.append('')

        if obsidian:
            lines.append('---')
            lines.append('Related: [[GDD]], [[Technical Design]], [[Art Requirements]]')

        return '\n'.join(lines)


class TechnicalDesignConverter:
    """Converts GDD descriptions into technical design specifications for Unity."""

    @staticmethod
    def convert(gdd_text, profile_data=None, obsidian=False):
        """Generate a technical design document from GDD text."""
        is_indie = True
        team_size = (profile_data or {}).get('team_size', '1-3')
        engine = (profile_data or {}).get('engine', 'Unity')

        lines = []
        if obsidian:
            lines.append('---')
            title = (profile_data or {}).get('game_title', 'Untitled')
            lines.append(f'title: "{title} - Technical Design"')
            lines.append('type: technical-design')
            lines.append('engine: Unity')
            lines.append('tags: [tech-design, unity, development]')
            lines.append('---')
            lines.append('')

        lines.append(f"# Technical Design Document")
        if profile_data:
            lines.append(f"> Based on: **{profile_data.get('game_title', 'Untitled')}**")
        lines.append(f"> Engine: {engine} | Team: {team_size}")
        lines.append('')

        lines.append('## System Architecture')
        lines.append('')
        lines.append('```')
        lines.append('GameManager (singleton)')
        lines.append('  |')
        lines.append('  +-- InputManager')
        lines.append('  +-- SaveSystem')
        lines.append('  +-- AudioManager')
        lines.append('  +-- UIManager')
        lines.append('  +-- EventSystem')
        lines.append('```')
        lines.append('')

        lines.append('## Core Systems Required')
        lines.append('')
        systems = [
            ('PlayerController', 'Input handling, movement, animation state machine'),
            ('InventorySystem', 'Item data, UI, equip/use logic'),
            ('SaveLoadSystem', 'JSON serialization, auto-save, checkpoints'),
            ('AudioManager', 'SFX, music, volume control, pooling'),
            ('UIManager', 'Canvas management, screen transitions'),
            ('EventSystem', 'ScriptableObject events for loose coupling'),
        ]
        for name, desc in systems:
            lines.append(f'### {name}')
            lines.append(f'- {desc}')
            lines.append(f'- **Unity Component**: MonoBehaviour or ScriptableObject')
            if is_indie:
                lines.append(f'- **Priority**: High (MVP required)')
            lines.append('')

        lines.append('## Key Variables')
        lines.append('')
        lines.append('| Variable | Type | Description | Default |')
        lines.append('|----------|------|-------------|---------|')
        lines.append('| `playerSpeed` | `float` | Movement speed | `5.0f` |')
        lines.append('| `maxHealth` | `int` | Player max HP | `100` |')
        lines.append('| `inventorySize` | `int` | Slot count | `20` |')
        lines.append('| `saveInterval` | `float` | Auto-save seconds | `60.0f` |')
        lines.append('| `cameraFollowSpeed` | `float` | Camera lerp speed | `3.0f` |')
        lines.append('')

        lines.append('## Unity Events')
        lines.append('')
        lines.append('| Event | Triggered By | Listeners |')
        lines.append('|-------|-------------|-----------|')
        lines.append('| `OnPlayerDeath` | Player HP <= 0 | UIManager, AudioManager, SaveSystem |')
        lines.append('| `OnItemCollected` | Pickup collision | Inventory, UI, AudioManager |')
        lines.append('| `OnLevelComplete` | Win condition met | SaveSystem, UIManager |')
        lines.append('| `OnGamePause` | Input | UIManager, AudioManager |')
        lines.append('')

        if obsidian:
            lines.append('## UI Requirements')
            lines.append('')
            lines.append('```mermaid')
            lines.append('graph TD')
            lines.append('    MainMenu --> NewGame')
            lines.append('    MainMenu --> LoadGame')
            lines.append('    MainMenu --> Settings')
            lines.append('    NewGame --> HUD')
            lines.append('    LoadGame --> HUD')
            lines.append('    HUD --> HealthBar')
            lines.append('    HUD --> Inventory')
            lines.append('    HUD --> Minimap')
            lines.append('```')
            lines.append('')

        lines.append('## Art/Audio Asset Requirements')
        lines.append('')
        lines.append('### Art')
        lines.append('| Asset | Type | Count | Priority |')
        lines.append('|-------|------|-------|----------|')
        lines.append('| Player Character | Sprite/Model | 1 | MVP |')
        lines.append('| Enemies | Sprite/Model | 3-5 | MVP |')
        lines.append('| Environment Tiles | Sprite/Texture | 10-20 | MVP |')
        lines.append('| UI Elements | Sprite | 20-30 | MVP |')
        lines.append('| VFX | Particle | 5-10 | Post-MVP |')
        lines.append('')

        lines.append('### Audio')
        lines.append('| Asset | Type | Count | Priority |')
        lines.append('|-------|------|-------|----------|')
        lines.append('| BGM | Music | 2-3 | MVP |')
        lines.append('| SFX: Actions | Audio | 5-10 | MVP |')
        lines.append('| SFX: UI | Audio | 3-5 | MVP |')
        lines.append('| SFX: Ambient | Audio | 2-3 | Post-MVP |')
        lines.append('')

        lines.append('## Development Priority')
        lines.append('')
        lines.append('| Phase | Duration | Deliverable |')
        lines.append('|-------|----------|-------------|')
        lines.append('| Phase 1: Core Loop | 1-2 weeks | Player moves, interacts, basic UI |')
        lines.append('| Phase 2: Systems | 2-3 weeks | Inventory, save, events |')
        lines.append('| Phase 3: Content | 2-4 weeks | Levels, items, enemies |')
        lines.append('| Phase 4: Polish | 1-2 weeks | VFX, audio, balance |')
        lines.append('| Phase 5: Release | 1 week | Build, store pages |')
        lines.append('')

        return '\n'.join(lines)


class ConsistencyChecker:
    """Cross-checks game design elements for contradictions."""

    def __init__(self, profile_data=None):
        self.profile = profile_data or {}
        self.is_indie = self._is_indie()

    def _is_indie(self):
        team = str(self.profile.get('team_size', '1-3'))
        return any(t in team for t in ['1', '2', '3', 'small', 'indie'])

    def check(self, design_data):
        """Run all consistency checks and return report."""
        issues = []

        issues.extend(self._check_gameplay_vs_story(design_data))
        issues.extend(self._check_worldbuilding_vs_mechanics(design_data))
        issues.extend(self._check_audience_vs_difficulty(design_data))
        issues.extend(self._check_art_vs_scope(design_data))
        issues.extend(self._check_monetization_vs_experience(design_data))
        issues.extend(self._check_complexity_vs_team(design_data))

        return {
            'timestamp': datetime.now().isoformat(),
            'profile': self.profile.get('game_title', 'Untitled'),
            'total_issues': len(issues),
            'critical': len([i for i in issues if i['severity'] == 'critical']),
            'warning': len([i for i in issues if i['severity'] == 'warning']),
            'info': len([i for i in issues if i['severity'] == 'info']),
            'issues': issues,
        }

    def _check_gameplay_vs_story(self, data):
        issues = []
        genre = str(self.profile.get('genre', '')).lower()
        story = str(data.get('story_tone', '')).lower()

        if 'action' in genre and 'slow' in story:
            issues.append({
                'severity': 'warning',
                'category': 'gameplay_vs_story',
                'title': 'Pacing mismatch',
                'description': 'Action genre with slow-paced story may conflict with player expectations.',
                'suggestion': 'Consider faster narrative delivery or adjust genre focus.'
            })
        return issues

    def _check_worldbuilding_vs_mechanics(self, data):
        issues = []
        mechanics = str(data.get('core_mechanics', '')).lower()
        world = str(data.get('world_rules', '')).lower()

        if 'magic' in world and 'no' in mechanics and 'magic' in mechanics:
            issues.append({
                'severity': 'critical',
                'category': 'worldbuilding_vs_mechanics',
                'title': 'Magic contradiction',
                'description': 'World has magic but core mechanics exclude it.',
                'suggestion': 'Either add magic mechanics or remove magic from worldbuilding.'
            })
        return issues

    def _check_audience_vs_difficulty(self, data):
        issues = []
        audience = str(self.profile.get('target_audience', '')).lower()
        difficulty = str(data.get('difficulty', '')).lower()

        if ('casual' in audience or 'mobile' in audience) and ('hardcore' in difficulty or 'very hard' in difficulty):
            issues.append({
                'severity': 'critical',
                'category': 'audience_vs_difficulty',
                'title': 'Audience/difficulty mismatch',
                'description': f'Target audience is {audience} but difficulty is set to {difficulty}.',
                'suggestion': 'Add difficulty options or adjust target audience.'
            })
        return issues

    def _check_art_vs_scope(self, data):
        issues = []
        art_style = str(self.profile.get('visual_style', '')).lower()
        scope = str(self.profile.get('scope', '')).lower()

        high_detail_styles = ['realistic', '3d realistic', 'photorealistic']
        indie_scopes = ['small', 'mvp', 'prototype', 'minimal']

        if any(s in art_style for s in high_detail_styles) and any(s in scope for s in indie_scopes):
            issues.append({
                'severity': 'critical',
                'category': 'art_vs_scope',
                'title': 'Art scope too ambitious',
                'description': f'Realistic art style conflicts with {scope} production scope for indie team.',
                'suggestion': 'Consider stylized/low-poly art or reduce scope.'
            })
        return issues

    def _check_monetization_vs_experience(self, data):
        issues = []
        monetization = str(data.get('monetization', '')).lower()
        genre = str(self.profile.get('genre', '')).lower()

        if 'pay-to-win' in monetization or 'pay to win' in monetization:
            issues.append({
                'severity': 'warning',
                'category': 'monetization_vs_experience',
                'title': 'P2W design risk',
                'description': 'Pay-to-win monetization can severely damage player retention.',
                'suggestion': 'Use cosmetic or expansion-based monetization instead.'
            })
        return issues

    def _check_complexity_vs_team(self, data):
        issues = []
        if not self.is_indie:
            return issues

        systems = data.get('systems_count', 0)
        if systems > 8:
            issues.append({
                'severity': 'critical',
                'category': 'complexity_vs_team',
                'title': 'Too many systems for indie team',
                'description': f'{systems} systems planned for a small team. Risk of never finishing.',
                'suggestion': 'Cut to 3-4 core systems for MVP. Add extras post-launch.'
            })
        elif systems > 5:
            issues.append({
                'severity': 'warning',
                'category': 'complexity_vs_team',
                'title': 'System count high for MVP',
                'description': f'{systems} systems may be too many for initial release.',
                'suggestion': 'Prioritize 3 core systems, defer the rest.'
            })
        return issues

    def to_markdown(self, report, obsidian=False):
        lines = []
        if obsidian:
            lines.append('---')
            lines.append(f'title: "Consistency Review - {report.get("profile", "")}"')
            lines.append('type: consistency-review')
            lines.append('tags: [review, quality-assurance]')
            lines.append('---')
            lines.append('')

        total = report['total_issues']
        critical = report['critical']
        warning = report['warning']
        info = report['info']

        lines.append(f"# Consistency Review Report")
        lines.append(f"**Project**: {report['profile']} | **Date**: {report['timestamp'][:10]}")
        lines.append('')
        lines.append(f"| Severity | Count |")
        lines.append(f"|----------|-------|")
        lines.append(f"| Critical | {critical} |")
        lines.append(f"| Warning | {warning} |")
        lines.append(f"| Info | {info} |")
        lines.append(f"| **Total** | **{total}** |")
        lines.append('')

        for issue in report['issues']:
            sev = issue['severity']
            icon = 'X' if sev == 'critical' else '!' if sev == 'warning' else 'i'
            lines.append(f"### [{icon.upper()}] {issue['title']}")
            lines.append(f"- **Category**: {issue['category']}")
            lines.append(f"- **Severity**: {sev}")
            lines.append(f"- **Issue**: {issue['description']}")
            lines.append(f"- **Fix**: {issue['suggestion']}")
            lines.append('')

        if obsidian:
            lines.append('---')
            lines.append('Related: [[Project Profile]], [[GDD]], [[Technical Design]]')

        return '\n'.join(lines)


class ReviewScorer:
    """Scores game design proposals on key metrics."""

    METRICS = [
        ('fun_potential', 'Fun Potential', 'How engaging is the core concept?'),
        ('dev_difficulty', 'Development Difficulty', 'How hard is this to build?'),
        ('indie_feasibility', 'Indie Feasibility', 'Can a small team pull this off?'),
        ('replay_value', 'Replay Value', 'Will players come back?'),
        ('system_clarity', 'System Clarity', 'How well-defined are the systems?'),
        ('risk_level', 'Risk Level', 'What could go wrong?'),
    ]

    @staticmethod
    def score(design_text, profile_data=None):
        """Generate review scores based on design analysis."""
        text_lower = design_text.lower()
        is_indie = True
        if profile_data:
            team = str(profile_data.get('team_size', '1-3'))
            is_indie = any(t in team for t in ['1', '2', '3', 'small', 'indie'])

        # Heuristic scoring based on design content
        scores = {}

        # Fun Potential
        fun_keywords = ['choice', 'progression', 'reward', 'challenge', 'explore', 'discover', 'create', 'compete', 'story', 'narrative', 'unique', 'twist']
        fun_count = sum(1 for kw in fun_keywords if kw in text_lower)
        scores['fun_potential'] = min(10, max(1, fun_count // 2 + 4))

        # Development Difficulty
        hard_keywords = ['multiplayer', 'network', 'open world', 'procedural', 'ai', 'physics', 'multiplayer', 'mmo', 'real-time strategy']
        hard_count = sum(1 for kw in hard_keywords if kw in text_lower)
        scores['dev_difficulty'] = min(10, max(1, hard_count * 2 + 3))

        # Indie Feasibility (inverse of difficulty, adjusted for indie)
        simple_keywords = ['single-player', '2d', 'pixel', 'turn-based', 'simple', 'minimal', 'mvp']
        simple_count = sum(1 for kw in simple_keywords if kw in text_lower)
        scores['indie_feasibility'] = min(10, max(1, 10 - hard_count + simple_count))

        # Replay Value
        replay_keywords = ['random', 'procedural', 'roguelike', 'multiple endings', 'choice', 'build', 'craft', 'mod', 'sandbox']
        replay_count = sum(1 for kw in replay_keywords if kw in text_lower)
        scores['replay_value'] = min(10, max(1, replay_count * 2 + 3))

        # System Clarity
        clarity_keywords = ['formula', 'table', 'rule', 'condition', 'requirement', 'formula', 'calculate', 'balance']
        clarity_count = sum(1 for kw in clarity_keywords if kw in text_lower)
        scores['system_clarity'] = min(10, max(1, clarity_count * 2 + 3))

        # Risk Level
        risk_keywords = ['untested', 'experimental', 'new genre', 'innovative', 'first', 'unknown', 'complex']
        risk_count = sum(1 for kw in risk_keywords if kw in text_lower)
        scores['risk_level'] = min(10, max(1, risk_count * 2 + 2))

        return {
            'timestamp': datetime.now().isoformat(),
            'project': profile_data.get('game_title', 'Untitled') if profile_data else 'Unknown',
            'scores': scores,
            'overall_score': round(sum(scores.values()) / len(scores), 1),
            'indie_ready': scores['indie_feasibility'] >= 6 and scores['dev_difficulty'] <= 7,
            'recommendations': ReviewScorer._generate_recommendations(scores, is_indie),
        }

    @staticmethod
    def _generate_recommendations(scores, is_indie):
        recs = []
        if scores['dev_difficulty'] >= 8:
            recs.append('Reduce scope: Cut 1-2 systems to lower development risk.')
        if scores['indie_feasibility'] <= 4:
            recs.append('High risk for indie team: Consider a simpler MVP first.')
        if scores['system_clarity'] <= 4:
            recs.append('Define systems more clearly: Add formulas, tables, and rules.')
        if scores['fun_potential'] <= 5:
            recs.append('Strengthen core loop: Add meaningful choices and feedback.')
        if scores['replay_value'] <= 4:
            recs.append('Add replay hooks: Randomization, progression, or meta-game.')
        if scores['risk_level'] >= 8:
            recs.append('High risk: Prototype the riskiest mechanic first.')
        if not recs:
            recs.append('Design looks solid. Focus on execution.')
        return recs

    @staticmethod
    def to_markdown(result, obsidian=False):
        lines = []
        if obsidian:
            lines.append('---')
            lines.append(f'title: "Review Score - {result.get("project", "")}"')
            lines.append('type: review-score')
            lines.append('tags: [review, scoring]')
            lines.append('---')
            lines.append('')

        lines.append(f"# Design Review Score")
        lines.append(f"**Project**: {result['project']} | **Overall**: {result['overall_score']}/10")
        if result['indie_ready']:
            lines.append('> Ready for indie development.')
        else:
            lines.append('> Not yet ready for indie development. See recommendations.')
        lines.append('')

        lines.append('| Metric | Score |')
        lines.append('|--------|-------|')
        labels = dict(ReviewScorer.METRICS)
        for key, label in ReviewScorer.METRICS:
            score = result['scores'].get(key, 0)
            bar = '█' * score + '░' * (10 - score)
            lines.append(f'| {label} | {bar} {score}/10 |')
        lines.append('')

        lines.append('## Recommendations')
        lines.append('')
        for rec in result['recommendations']:
            lines.append(f'- {rec}')
        lines.append('')

        if obsidian:
            lines.append('---')
            lines.append('Related: [[GDD]], [[Technical Design]], [[Consistency Review]]')

        return '\n'.join(lines)


def main():
    """CLI entry point."""
    if len(sys.argv) < 2:
        print(json.dumps({
            'usage': 'python3 workflow_assistant.py <command> [args...]',
            'commands': [
                'profile-create <title> <genre> <platform> <audience> <core_loop> <visual_style> <engine> <team_size> <scope> <ref_games>',
                'profile-list',
                'profile-show <filename>',
                'tech-convert <profile_file> <gdd_text_file>',
                'consistency-check <profile_file> <design_json_file>',
                'review-score <design_text_file> [profile_file]',
                'obsidian-export <profile_file>',
            ]
        }, indent=2))
        return

    cmd = sys.argv[1]

    if cmd == 'profile-create':
        if len(sys.argv) < 12:
            print('Error: profile-create requires 10 arguments')
            sys.exit(1)
        profile = ProjectProfile({
            'game_title': sys.argv[2],
            'genre': sys.argv[3],
            'platform': sys.argv[4],
            'target_audience': sys.argv[5],
            'core_loop': sys.argv[6],
            'visual_style': sys.argv[7],
            'engine': sys.argv[8],
            'team_size': sys.argv[9],
            'scope': sys.argv[10],
            'reference_games': sys.argv[11].split(','),
        })
        filepath = profile.save()
        print(json.dumps({'status': 'saved', 'file': filepath, 'profile': profile.data}, indent=2))

    elif cmd == 'profile-list':
        profiles = ProjectProfile.list_all()
        print(json.dumps({'profiles': profiles}, indent=2))

    elif cmd == 'profile-show':
        if len(sys.argv) < 3:
            print('Error: profile-show requires filename')
            sys.exit(1)
        profile = ProjectProfile.load(sys.argv[2])
        obsidian = '--obsidian' in sys.argv
        print(profile.to_markdown(obsidian=obsidian))

    elif cmd == 'tech-convert':
        if len(sys.argv) < 4:
            print('Error: tech-convert requires profile file and GDD text file')
            sys.exit(1)
        profile = ProjectProfile.load(sys.argv[2])
        with open(sys.argv[3], 'r', encoding='utf-8') as f:
            gdd_text = f.read()
        obsidian = '--obsidian' in sys.argv
        tech = TechnicalDesignConverter.convert(gdd_text, profile.data, obsidian=obsidian)
        print(tech)

    elif cmd == 'consistency-check':
        if len(sys.argv) < 4:
            print('Error: consistency-check requires profile file and design JSON file')
            sys.exit(1)
        profile = ProjectProfile.load(sys.argv[2])
        with open(sys.argv[3], 'r', encoding='utf-8') as f:
            design_data = json.load(f)
        checker = ConsistencyChecker(profile.data)
        report = checker.check(design_data)
        obsidian = '--obsidian' in sys.argv
        print(checker.to_markdown(report, obsidian=obsidian))

    elif cmd == 'review-score':
        if len(sys.argv) < 3:
            print('Error: review-score requires design text file')
            sys.exit(1)
        with open(sys.argv[2], 'r', encoding='utf-8') as f:
            design_text = f.read()
        profile_data = None
        if len(sys.argv) > 3 and not sys.argv[3].startswith('--'):
            profile = ProjectProfile.load(sys.argv[3])
            profile_data = profile.data
        obsidian = '--obsidian' in sys.argv
        result = ReviewScorer.score(design_text, profile_data)
        print(ReviewScorer.to_markdown(result, obsidian=obsidian))

    elif cmd == 'obsidian-export':
        if len(sys.argv) < 3:
            print('Error: obsidian-export requires profile file')
            sys.exit(1)
        profile = ProjectProfile.load(sys.argv[2])
        print(profile.to_markdown(obsidian=True))

    else:
        print(f'Unknown command: {cmd}')
        sys.exit(1)


if __name__ == '__main__':
    main()
