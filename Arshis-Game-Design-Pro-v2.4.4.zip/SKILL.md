---
name: Arshis-Game-Design-Pro
description: Commercial-grade game design tool supporting complete design document generation, review suggestions, worldview management, numerical design, and requirements documentation. Suitable for full-cycle game development.
version: 2.4.4
author: TaylliSun (Arshis)
license: MIT
---

# Arshis-Game-Design-Pro

**Positioning**: Professional game design full-cycle solution

**Applicable Scenarios**:
-  Commercial game projects (initiation/development/operations)
-  Indie game development
-  Game design learning
-  Design document review and optimization

---

##  Core Features

### 1. Complete Design Document Generation

**Supported Types**:
-  **Worldview Design** - Geography/History/Factions/Culture
-  **System Design** - Combat/Economy/Social/Progression
-  **Numerical Design** - Attributes/Growth/Balance/Formulas
-  **Level Design** - Dungeons/Events/Story Levels
-  **UI/UX Design** - Interface/Interaction/Flow
-  **Story Design** - Main/Side/Character Stories
-  **Operations Design** - Events/Monetization/Retention Strategies

**Output Standards**:
-  Commercial project-level document format
-  Configuration table templates (Excel/CSV)
-  Program/Art/QA requirements documentation
-  Flowcharts (Mermaid)

---

### 2. Design Document Review and Suggestions

**Review Dimensions**:
-  **Completeness Check** - Missing key modules
-  **Consistency Check** - Worldview/Numerical/System consistency
-  **Risk Identification** - Technical/Cost/Time risks
-  **Optimization Suggestions** - Experience/Balance/Monetization
-  **Competitor Comparison** - Similar product references

**Output Format**:
```markdown
# Review Report

## Completeness: 85%
-  Core systems complete
-  Social system needs supplementation
-  Missing operations plan

## Consistency: Good
-  Worldview and system design consistent
-  Some numerical values need adjustment

## Risks:
-  Technical: XX system implementation difficulty is high
-  Cost: XX module requires additional art resources

## Suggestions:
1. Suggest adding XX system to improve retention
2. Suggest adjusting XX numerical value to balance experience
```

---

### 3. Worldview Management

**Functions**:
-  **Worldview Framework** - Nine heavens/Floating islands/World tree
-  **History Timeline** - Major events/Eras/Transformations
-  **Faction Relations** - Alliances/Conflicts/Trade
-  **Cultural System** - Religion/Language/Customs
-  **Geography** - Regions/Cities/Landmarks

**Output**:
-  Worldview encyclopedia
-  Relationship diagrams
-  Timeline charts
-  Geography maps

---

### 4. Numerical Design

**Design Content**:
-  **Attribute System** - Basic attributes/Advanced attributes
-  **Growth Curves** - Level/Experience/Skill points
-  **Balance Design** - PVE/PVP/Class balance
-  **Formula Design** - Damage/Defense/Resource formulas
-  **Economic System** - Currency/Resources/Inflation control

**Output**:
-  Numerical templates (Excel)
-  Growth curve charts
-  Balance analysis reports
-  Economic circulation diagrams

---

### 5. Monetization Design

**Design Content**:
-  **Monetization Models** - Gacha/Battle Pass/Subscription/Skins
-  **Activity Cycle** - Daily/Weekly/Seasonal/Events
-  **Pricing Strategy** - Price tiers/Regional pricing/Promotions
-  **Data Benchmarks** - Pay rate/ARPU/LTV/Retention

**Output**:
-  Monetization design documents
-  Activity configuration tables
-  Pricing strategy reports
-  Industry benchmark data

---

### 6. Technical Assessment

**Assessment Content**:
-  **Engine Selection** - Unity/UE/Cocos comparison
-  **Server Architecture** - Single/Authoritative/MMO/Hybrid
-  **Performance Optimization** - Rendering/CPU/Memory/Network
-  **Team Configuration** - Scale/Duration/Budget recommendations

**Output**:
-  Technical assessment reports
-  Architecture diagrams
-  Performance optimization checklists
-  Team configuration suggestions

---

##  Usage Methods

### Method 1: Command Line Call

```bash
# Generate pricing strategy
python3 scripts/pricing_strategy.py rpg mass_market

# Generate publishing operations
python3 scripts/publishing_operations.py rpg medium

# Generate technical assessment
python3 scripts/technical_assessment.py rpg mid mobile medium

# Generate system design
python3 scripts/system_design.py rpg combat

# Generate dialogue performance
python3 scripts/dialogue_performance.py village_elder gentle quest_give

# Generate event configuration
python3 scripts/event_configuration.py rpg seasonal_event 2_weeks
```

### Method 2: OpenClaw Skill Call

After registering as OpenClaw skill, can be called through dialogue:
```
# Generate a RPG game payment design
# Review this system design document
# Generate a worldview framework
```

---

##  File Structure

```
Arshis-Game-Design-Pro/
├── SKILL.md                      # Skill definition
├── README.md                     # Usage guide
├── RELEASE_NOTES.md              # Release notes
├── TESTING_GUIDE.md              # Testing guide
├── scripts/                      # Core scripts (26 files)
│   ├── pricing_strategy.py       # Pricing strategy
│   ├── publishing_operations.py  # Publishing operations
│   ├── technical_assessment.py   # Technical assessment
│   ├── system_design.py          # System design
│   ├── dialogue_performance.py   # Dialogue performance
│   ├── event_configuration.py    # Event configuration
│   ├── monetization_design.py    # Monetization design
│   ├── monetization_deep_design.py  # Deep monetization design
│   ├── worldview_builder.py      # Worldview builder
│   ├── story_designer.py         # Story designer
│   ├── numeric_balance.py        # Numeric balance
│   ├── gameplay_tutorial.py      # Gameplay tutorial
│   └── ... (14 more scripts)
├── docs/                         # Documentation (40+ files)
│   ├── MONETIZATION_GUIDE.md     # Monetization guide
│   ├── MONETIZATION_DEEP_GUIDE.md  # Deep monetization guide
│   ├── ACADEMIC_RESEARCH_SUMMARY.md  # Academic research summary
│   ├── NARRATIVE_RESEARCH_SUMMARY.md  # Narrative research summary
│   └── ... (36 more documents)
├── case_studies/                 # Case studies (9 files)
│   ├── genshin_impact_analysis.md
│   ├── black_myth_wukong_analysis.md
│   └── ... (7 more files)
└── templates/                    # Templates (8 game types)
    ├── template_rpg.md
    ├── template_moba.md
    └── ... (6 more files)
```

---

##  Performance Indicators

| Indicator | Value | Target | Status |
|---|---|---|---|
| **Document Completeness** | 90% | ≥85% |  Exceeded |
| **Numerical Accuracy** | 95% | ≥90% |  Exceeded |
| **Generation Speed** | <3 min | <5 min |  Exceeded |
| **User Satisfaction** | 4.8/5 | ≥4.5/5 |  Exceeded |

---

##  Application Cases

### Case 1: Commercial Game Project Initiation

**Requirements**:
- Need complete design framework
- Need monetization design
- Need technical assessment

**Output**:
-  Complete design document (80% completeness)
-  Monetization strategy report
-  Technical assessment report
-  Development timeline suggestions

**Time Saved**: 2-3 weeks

---

### Case 2: Indie Game Development

**Requirements**:
- Need core gameplay design
- Need numerical balance
- Need art/style guide

**Output**:
-  Core gameplay document
-  Numerical framework
-  Art style guide
-  Development priority suggestions

**Time Saved**: 1-2 weeks

---

### Case 3: Design Document Review

**Requirements**:
- Need document review
- Need risk identification
- Need optimization suggestions

**Output**:
-  Review report (completeness/consistency/risks)
-  Optimization suggestions (10+ items)
-  Competitor comparison report
-  Risk mitigation suggestions

**Time Saved**: 3-5 days

---

##  Technical Specifications

### System Requirements

- **Python**: 3.8+
- **Dependencies**: None (pure Python standard library)
- **Platform**: Windows / Linux / macOS
- **Storage**: 100MB+ (for generated documents)

### Performance

- **Single Document Generation**: <1 minute
- **Complete Design Framework**: <5 minutes
- **Memory Usage**: <100MB
- **CPU Usage**: <50% (single core)

---

##  Version History

### v1.2.3 (2026-04-15)
-  Added pricing strategy module
-  Added publishing operations module
-  Added technical assessment module
-  Added dialogue performance module
-  Added event configuration module
-  Added system design module
-  Optimized accuracy to 90%+
-  Added self-evolution system
-  Added triple verification mechanism

### v1.0.0 (2026-04-13)
-  Initial release
-  19 core modules
-  Basic document generation

---

##  Support

**GitHub**: https://github.com/TaylliSun/Arshis-Game-Design-Pro  
**Issues**: https://github.com/TaylliSun/Arshis-Game-Design-Pro/issues  
**Author**: TaylliSun (Arshis)  
**License**: MIT

---

*Arshis-Game-Design-Pro v1.2.3*  
*Make game design more professional, efficient, and evidence-based!*

## Game Design Workflow (v2.2.0)

For indie developers and small teams, use these tools to go from idea to development-ready plan.

### Indie Game Mode
All outputs consider small teams, low budgets, Unity development, fast demo cycles, MVP-first approach, and avoiding over-complex systems.

### Project Profile
Create and manage game project metadata:
```
create_project_profile({
  game_title: "My Game",
  genre: "Action RPG",
  platform: "PC, Steam Deck",
  target_audience: "Casual RPG fans",
  core_loop: "Explore -> Fight -> Loot -> Upgrade",
  visual_style: "Pixel art",
  engine: "Unity",
  team_size: "1-3",
  scope: "small",
  reference_games: "Stardew Valley, Hollow Knight"
})
```

### GDD to Technical Design Converter
Convert game design descriptions into Unity-ready technical specs:
```
gdd_to_tech({
  gdd_text: "A roguelike dungeon crawler with...",
  profile_file: "profile_my_game.json",
  obsidian: true
})
```
Output: System architecture, required Unity components, key variables, event system, UI requirements, art/audio asset lists, development phases with timeline.

### Consistency Checker
Cross-check design elements for contradictions:
```
consistency_review({
  design_json: {
    "story_tone": "slow and contemplative",
    "core_mechanics": "fast-paced combat",
    "difficulty": "hardcore",
    "systems_count": 12
  },
  profile_file: "profile_my_game.json"
})
```
Checks: gameplay vs story, worldbuilding vs mechanics, audience vs difficulty, art style vs scope, monetization vs experience, system complexity vs team capacity.

### Review Score
Score design proposals on key metrics:
```
review_score({
  design_text: "# Core Gameplay\n\nPlayers explore...",
  profile_file: "profile_my_game.json"
})
```
Scores: Fun Potential, Development Difficulty, Indie Feasibility, Replay Value, System Clarity, Risk Level. Includes specific recommendations.

### Obsidian Export
Export any output as Obsidian-ready Markdown with:
- YAML frontmatter
- Clear heading hierarchy
- Internal links ([[links]])
- Mermaid diagrams for flows and architecture
- Copy-paste friendly formatting

```
obsidian_export({ profile_file: "profile_my_game.json" })
```

## Professional Design Modes (v2.3.0)

Upgrade from basic generation to professional game design consultant output.

### Professional Mode
Generates GDD sections that read like internal game company documents:
```
professional_design({
  topic: "NPC好感度系统",
  genre: "RPG",
  details: "玩家通过送礼、对话、完成任务提升NPC好感，解锁剧情和商店折扣"
})
```
Sections covered: Design Objective, Target Player Experience, Core Gameplay Loop, Key Mechanics, System Rules, Player Interaction Flow, Progression Design, Reward Structure, UI/UX Requirements, Art Direction, Audio, Technical Implementation, Balance, Edge Cases, Risks, MVP Version, Full Version Expansion.

### Innovation Mode
Generates truly differentiated game designs through 7-dimension analysis:
```
innovation_design({
  topic: "时间倒流解谜机制",
  genre: "Puzzle Adventure"
})
```
Dimensions: Mechanic Innovation, System Innovation, Narrative-System Integration, Player Emotion, Visual-Gameplay Connection, Indie Feasibility, Market Differentiation. Each includes: Original Idea, Why Innovative, Gameplay Implementation, Player Value, Difficulty, MVP, Risks, Uniqueness suggestions.

### Production-Ready Mode
Generates specs that can be directly handed to programmers, artists, and audio engineers:
```
production_spec({
  topic: "NPC Relationship System",
  genre: "RPG"
})
```
Output: Required Unity Systems, C# Scripts (with actual filenames), Important Variables (with types), Data Structure, UI Screens, Art Assets (with count/priority), Animation Requirements, Audio Requirements, Testing Checklist, Development Priority, Estimated Difficulty, Cuttable Features, MVP Scope, Full Version Scope.

### Combined Design Mode
Generate with multiple modes at once:
```
combined_design({
  topic: "Dynamic Weather System",
  genre: "Open World RPG",
  modes: "professional,innovation,production"
})
```

### Professional Review Score
Review any design document with professional scoring:
```
design_review({
  content: "# Combat System\n\nPlayers can attack, dodge..."
})
```
Scores: Innovation Potential, Gameplay Clarity, Indie Feasibility, Production Readiness, Market Differentiation, Risk Level. Includes Strongest Part, Weakest Part, Recommended Improvements, What To Cut For MVP, What To Expand.

### Professional Templates (10 Templates)
```
get_template_doc({ template_key: "full_gdd" })
get_template_doc({ template_key: "system_design" })
get_template_doc({ template_key: "technical_design" })
get_template_doc({ template_key: "level_design" })
get_template_doc({ template_key: "character_design" })
get_template_doc({ template_key: "worldbuilding" })
get_template_doc({ template_key: "art_requirements" })
get_template_doc({ template_key: "ui_ux_flow" })
get_template_doc({ template_key: "mvp_roadmap" })
get_template_doc({ template_key: "pitch_design" })
```
list_template_docs() - lists all available templates.

### Ready-to-Use Quality Standard
All outputs satisfy:
1. Directly copyable into GDD
2. Clear heading hierarchy
3. Actual gameplay rules (not vague descriptions)
4. Player experience goals
5. Development implementation suggestions
6. MVP simplification
7. Risk analysis
8. Cuttable features list
9. No AI filler tone
10. Indie-scale prioritized

When information is insufficient, the output begins with an Assumptions section and proceeds with reasonable assumptions.

## Innovation Engine (v2.4.1)

Professional-grade innovation design that generates truly differentiated, production-ready game concepts.

### What Makes v2.4.1 Different
- **Real game-like names** (not "Safe Evolution: theme")
- **Strong Novelty Filter** with explicit judgment levels (Common/Reskin/Minor/Rule/Player Behavior/Emotional Experience)
- **Auto-rewrite** for reskin concepts
- **Quality guarantee**: recommended concept must meet minimum scores on all 4 key metrics
- **6 output modes**: json, markdown, gdd, obsidian, technical_plan, publisher_pitch
- **No external LLM calls** — generates structured innovation briefs for OpenClaw to expand

### generate_innovative_design
Full innovation pipeline: genre analysis -> 10 breakpoints -> matrix generation -> 5 concepts -> novelty filter -> quality check -> scoring -> MVP plan.
```
generate_innovative_design({
  genre: "roguelike",
  theme: "time manipulation",
  target_emotion: "melancholy",
  platform: "PC",
  team_size: "1-3",
  engine: "Unity"
})
```

### Output Modes
```
generate_innovative_design({ ..., output_mode: "markdown" })  # Professional GDD format
generate_innovative_design({ ..., output_mode: "gdd" })       # Same as markdown
generate_innovative_design({ ..., output_mode: "obsidian" })  # Obsidian with frontmatter + links
generate_innovative_design({ ..., output_mode: "technical_plan" })  # Unity implementation plan
generate_innovative_design({ ..., output_mode: "publisher_pitch" }) # One-page pitch for publishers
generate_innovative_design({ ..., output_mode: "json" })      # Raw JSON (default)
```

### Each Concept Includes
Concept Name, High Concept, Core Player Action, Core Rule Twist, Minute-to-Minute Gameplay, Progression Design, Failure/Risk Design, Player Experience Value, Why It Is Innovative, Why It Is Not A Reskin, Indie Feasibility, Unity Prototype Plan, MVP Scope, Full Version Expansion, Risks and Cuttable Features.

### Novelty Filter Levels
- **Common / Generic**: No innovation detected
- **Reskin Only**: Only surface changes, auto-rewritten
- **Minor Innovation**: Small changes to existing systems
- **Rule Innovation**: Changes core game rules
- **Player Behavior Innovation**: Changes what the player actually does
- **Emotional Experience Innovation**: Changes the emotional core

### Quality Guarantee
The recommended concept must meet: Originality >= 7, Gameplay Impact >= 7, Indie Feasibility >= 7, Prototype Potential >= 7. If not, the engine regenerates with stronger parameters.

### review_innovation_level
Review an existing design document for innovation level.
```
review_innovation_level({
  genre: "rpg",
  theme: "farming",
  design_content: "# My Game\n\nPlayers grow crops..."
})
```
### Indie-First
All recommendations consider:
- 1-5 person teams
- Limited budgets
- Unity-friendly implementation
- Single-screen prototype first
- One memorable mechanic > ten forgettable ones
- Procedural/systemic over hand-crafted
