# Arshis-Game-Design-Pro v2.4.3 — Usage Examples

## Example 1: Generate an Innovative Game Concept

**Scenario**: You want to make a roguelike with time manipulation, targeting a melancholy emotional experience, for a 1-3 person Unity team.

**Input**:
```
generate_innovative_design({
  genre: "roguelike",
  theme: "time manipulation",
  target_emotion: "melancholy",
  output_mode: "markdown"
})
```

**Output Summary**:
- Genre Convention Analysis: Standard roguelike mechanics (permadeath, random generation, run-based progression, item synergies)
- 10 Innovation Breakpoints: Questions to diverge from conventions (core mechanic, player role, resource system, etc.)
- 5 Innovation Concepts:
  - **Safe** (7.7/10): Refines the formula with one clear innovation
  - **Moderate** (7.2/10): Replaces progression system with knowledge-based progression
  - **High** (7.7/10): Player is the dungeon itself, not the adventurer
  - **Experimental** (7.3/10): Failure permanently changes the world
  - **Indie** (8.3/10): Single-screen, one verb, emergent depth
- Each concept includes: novelty filter check (no reskins detected), 6-metric scoring, Unity prototype plan, MVP scope, full version expansion, risks and cuttable features
- Recommended: "The Compass" (Indie type, 8.3/10) — highest balance of innovation and feasibility

**When to Use**: You have a genre + theme and want truly differentiated design ideas.

---

## Example 2: Review an Existing Design's Innovation Level

**Scenario**: You wrote a draft for a farming RPG and want to know how innovative it is.

**Input**:
```
review_innovation_level({
  genre: "farming",
  theme: "moon colony",
  design_content: `# Moon Farm

Players grow crops on the moon, sell them for resources, and upgrade their habitat.
There are seasons, weather effects, and relationships with other colonists.
The game features 20+ crops, a community center to restore, and mining for underground resources.`
})
```

**Output Summary**:
- Innovation Score: 7.2/10 (Medium risk)
- Common Elements: Found standard farming mechanics (planting, harvesting, relationships, seasons)
- Different Elements: Moon setting is mentioned but not mechanically integrated
- Reskin Indicators: Setting changed to moon, but core loop identical to Stardew Valley
- Innovative Elements: None detected yet
- Improvement Suggestions:
  1. Apply Inversion: Instead of growing crops, maybe the player manages the colony's life support and crops are a resource, not the focus
  2. Constraint as Mechanic: Limited moon surface area forces players to choose what to grow carefully
  3. Consider Player Role Shift: What if the player is the moon's AI, not a farmer?
  4. Apply Emotion-First Design: Target loneliness or isolation instead of cozy satisfaction
- Indie Feasibility Tips: Cut any system that requires more than 1 person-week to prototype

**When to Use**: You have a design document and want honest feedback on its innovation level.

---

## Example 3: Convert GDD Idea into Unity Technical Planning

**Scenario**: You have an NPC relationship system idea and need a technical specification for developers.

**Input**:
```
gdd_to_tech({
  gdd_text: `NPC Relationship System

Players build relationships with NPCs through gifts, dialogue choices, and completing quests.
Each NPC has unique preferences, personality, and unlockable story arcs.
Relationship levels unlock new dialogue, shop discounts, and side quests.
Relationships decay over time if neglected.`,
  profile_file: "profile_my_game.json",
  output_mode: "technical_plan"
})
```

**Output Summary**:
```
# Technical Design Document
Based on: [Game Name]
Engine: Unity | Team: 1-3

## Required Unity Systems
- GameManager (singleton, scene management)
- InputManager (player input handling)
- SaveSystem (JSON serialization, checkpoints)
- EventSystem (ScriptableObject events)

## Core C# Scripts
- NPCRelationshipManager.cs
- RelationshipData.cs (ScriptableObject)
- GiftInteraction.cs
- DialogueConditionChecker.cs
- RelationshipDecaySystem.cs

## Important Variables
| Variable | Type | Description | Default |
|----------|------|-------------|---------|
| relationshipLevel | int | Current relationship tier (0-10) | 0 |
| giftPreference | enum | NPC gift preference category | None |
| dialogueUnlockThreshold | int | Relationship level for dialogue unlock | 3 |
| decayRate | float | Relationship decay per in-game day | 0.01 |

## Required UI
- Relationship Panel (shows current level, next unlock)
- Gift Selection Popup (shows preference hints)
- NPC Response Feedback (dialogue changes based on level)

## Art Assets
- NPC Expression Sprites: 5 per NPC (neutral, happy, sad, surprised, angry)
- Gift Icons: 20-30 items
- UI Elements: Relationship bar, preference indicators

## Development Priority
| Phase | Duration | Deliverable |
|-------|----------|-------------|
| Phase 1: Core | 1-2 weeks | Basic relationship meter, gift system |
| Phase 2: Systems | 2-3 weeks | Dialogue unlocks, decay, save/load |
| Phase 3: Content | 2-4 weeks | NPC stories, preferences, quests |
| Phase 4: Polish | 1-2 weeks | VFX, audio, balance |

## MVP Scope
One NPC, one gift type, three relationship levels. Test if the loop feels meaningful.

## Cuttable Features
- Decay system (defer)
- Multiple gift categories (start with one)
- Complex story arcs (start with simple dialogue changes)
```

**When to Use**: You have a game design idea and need a technical specification to hand to developers.
